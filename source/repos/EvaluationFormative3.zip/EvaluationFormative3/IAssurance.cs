﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationFormative3
{
    internal interface IAssurance
    {
        double MontantAssurance();
    }
}
