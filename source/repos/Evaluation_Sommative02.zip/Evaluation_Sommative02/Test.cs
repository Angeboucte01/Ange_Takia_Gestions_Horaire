﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evaluation_Sommative02
{
    internal class Test
    {
        static void Main(string[] args)
        {
            //Créer un médicament m1 avec le premier constructeur de la classe Médicament
            Medicament m1 = new Medicament();
            Medicament m2 = new Medicament("TYLENOL", "ACTETAMIQUE");
            // Créer un médicament m3 avec le troisième constructeur de la classe Médicament0
            Medicament m3 = new Medicament("TYLENOL", "ACTETAMIQUE",10.99);
            Console.WriteLine(m3.Egalite(m2));
            m2.AjouterEffet("Palpitation");
            m2.AjouterEffet("nausees");


            m3.AjouterEffet("Palpitation");
            m3.AjouterEffet("nausees");


        }
    }
}
